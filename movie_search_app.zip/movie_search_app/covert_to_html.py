import os

# Define the file paths
input_file_path = r"C:\Users\alknanda\Desktop\movie_search_app\templates\index.txt"
output_file_path = r"C:\Users\alknanda\Desktop\movie_search_app\templates\index.html"

try:
    # Read the content from the text file
    with open(input_file_path, 'r', encoding='utf-8') as text_file:
        text_content = text_file.read()
    
    # Convert the text to a basic HTML structure
    html_content = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<pre>
{text_content}
</pre>
</body>
</html>
"""

    # Write the HTML content to the output file
    with open(output_file_path, 'w', encoding='utf-8') as html_file:
        html_file.write(html_content)
    
    print(f"HTML file created successfully at: {output_file_path}")

except FileNotFoundError:
    print(f"Error: File not found at path {input_file_path}. Please check the file path.")
except Exception as e:
    print(f"An error occurred: {e}")
