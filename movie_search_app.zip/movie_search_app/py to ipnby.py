import nbformat
from nbformat.v4 import new_notebook, new_code_cell
import os

# Path to your Python file
python_file_path = r"C:\Users\alknanda\Desktop\movie_search_app\app.py"

# Output path for the Jupyter Notebook
notebook_file_path = python_file_path.replace(".py", ".ipynb")

# Read the Python script
if not os.path.exists(python_file_path):
    print(f"Error: File {python_file_path} does not exist.")
else:
    with open(python_file_path, 'r', encoding='utf-8') as py_file:
        code_lines = py_file.readlines()

    # Create a new Jupyter notebook
    notebook = new_notebook()
    notebook.cells.append(new_code_cell("".join(code_lines)))

    # Write the notebook to a file
    with open(notebook_file_path, 'w', encoding='utf-8') as nb_file:
        nbformat.write(notebook, nb_file)

    print(f"Conversion complete! Notebook saved as {notebook_file_path}")
